
export const environment = {
    production: false,
    auth: {
      domain: 'dev-j2zmhquusswqhon0.us.auth0.com',
      clientId: 'HDCqkPjrmAWGdmC39xd4UAyBxgfUhbTd',
      authorizationParams: {
        redirect_uri: window.location.origin
      }
    }
  };